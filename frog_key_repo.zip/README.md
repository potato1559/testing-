Frog Key site (Vercel) with expiring keys (12 hours)
-----------------------------------------------------

Files:

- index.html               // static frontend (calls /api/getkey and /api/validate)
- api/getkey.js            // serverless function that issues keys (in-memory)
- api/validate.js          // serverless function that validates keys (in-memory)
- roblox_executor_script.lua // LocalScript suited for executor environments (provided alongside)

Deployment notes:
- The serverless functions use a simple in-memory JS object to store keys. On Vercel or other serverless platforms this is ephemeral (will be reset if the instance restarts or scales). For a production, persistent solution, replace the storage with a database (Redis, Supabase, etc.).
- After deploying, you'll get a site URL like https://your-site.vercel.app. Put that URL into the Roblox script's SITE_URL variable (in the provided Lua file).
- The Lua script attempts to validate keys by contacting the `/api/validate?key=...` endpoint using several HTTP methods compatible with common executors (syn.request, http_request, request, or Roblox's HttpService if available).
- This is a proof-of-concept. Do not rely on the in-memory store for long-term persistence.
