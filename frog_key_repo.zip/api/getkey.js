// api/getkey.js
// Simple in-memory key store. Keys expire after 12 hours.
// Note: In serverless environments this in-memory store is ephemeral and will be lost if the instance restarts.
// For production, use a persistent store (Redis, DynamoDB, Supabase, etc.).

const KEY_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours
if (!global.__FROG_KEY_STORE) global.__FROG_KEY_STORE = {};

function makeKey() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let out = 'frog-';
  for (let i=0;i<18;i++) out += chars[Math.floor(Math.random()*chars.length)];
  return out;
}

export default function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  const key = makeKey();
  const now = Date.now();
  const expires_at = now + KEY_TTL_MS;
  global.__FROG_KEY_STORE[key] = { created_at: now, expires_at };
  return res.status(200).json({ key, created_at: now, expires_at });
}
