// api/validate.js
// Checks the in-memory store for key validity.
if (!global.__FROG_KEY_STORE) global.__FROG_KEY_STORE = {};

export default function handler(req, res) {
  const { key } = req.query || {};
  if (!key || typeof key !== 'string') return res.status(400).json({ valid: false, error: 'missing key' });
  const entry = global.__FROG_KEY_STORE[key];
  if (!entry) return res.status(200).json({ valid: false, reason: 'not_found' });
  const now = Date.now();
  if (now > entry.expires_at) { delete global.__FROG_KEY_STORE[key]; return res.status(200).json({ valid: false, reason: 'expired' }); }
  return res.status(200).json({ valid: true, created_at: entry.created_at, expires_at: entry.expires_at });
}
