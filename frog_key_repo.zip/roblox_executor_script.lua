-- Roblox executor-friendly script (LocalScript style)
-- This script is designed to run via executors (Xeno, Delta, Mame, etc.).
-- It shows a small key entry UI, validates the key with the server, and when valid shows the main cheat UI (ESP, Speed, Fly, etc.).
-- Replace SITE_URL with your deployed Vercel site URL (including https://).

local SITE_URL = "https://your-vercel-site.vercel.app" -- REPLACE this after deployment
local DISCORD_INVITE = "https://discord.gg/your-invite" -- optional

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local StarterGui = game:GetService("StarterGui")
local HttpService = game:GetService("HttpService")

-- Utilities for HTTP requests that work across many executors
local function httpRequest(url)
    -- Try syn.request
    local ok, res = pcall(function()
        if syn and syn.request then
            return syn.request({Url = url, Method = "GET"})
        end
        if http and http.request then
            return http.request(url)
        end
        if http_request then
            return http_request({Url = url, Method = "GET"})
        end
        if request then
            return request({Url = url, Method = "GET"})
        end
        -- Last resort: Roblox HttpService (may be disabled)
        if HttpService and HttpService.GetAsync then
            local body = HttpService:GetAsync(url)
            return {StatusCode = 200, Body = body}
        end
        error("No HTTP function available")
    end)
    if not ok then return nil, tostring(res) end
    return res, nil
end

-- Simple UI creation
local function createGui()
    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = "FrogKeyGui"
    screenGui.ResetOnSpawn = false
    screenGui.Parent = LocalPlayer:WaitForChild("PlayerGui")

    local frame = Instance.new("Frame", screenGui)
    frame.Size = UDim2.new(0,380,0,140)
    frame.Position = UDim2.new(0.5,-190,0.4,-70)
    frame.BackgroundColor3 = Color3.fromRGB(18,24,32)
    frame.BorderSizePixel = 0

    local title = Instance.new("TextLabel", frame)
    title.Size = UDim2.new(1,-20,0,28)
    title.Position = UDim2.new(0,10,0,8)
    title.BackgroundTransparency = 1
    title.Text = "Enter your key"
    title.TextColor3 = Color3.new(0.9,0.95,1)
    title.Font = Enum.Font.SourceSansBold
    title.TextSize = 20
    title.TextXAlignment = Enum.TextXAlignment.Left

    local textBox = Instance.new("TextBox", frame)
    textBox.Size = UDim2.new(1,-20,0,36)
    textBox.Position = UDim2.new(0,10,0,44)
    textBox.PlaceholderText = "Type your key here"
    textBox.ClearTextOnFocus = false
    textBox.Text = ""
    textBox.Font = Enum.Font.SourceSans
    textBox.TextSize = 18

    local joinBtn = Instance.new("TextButton", frame)
    joinBtn.Size = UDim2.new(0,140,0,34)
    joinBtn.Position = UDim2.new(0,10,1,-44)
    joinBtn.Text = "Join Discord"
    joinBtn.Font = Enum.Font.SourceSansBold
    joinBtn.TextSize = 16
    joinBtn.BackgroundColor3 = Color3.fromRGB(28,112,184)
    joinBtn.TextColor3 = Color3.fromRGB(1,1,1)

    local getKeyBtn = Instance.new("TextButton", frame)
    getKeyBtn.Size = UDim2.new(0,100,0,34)
    getKeyBtn.Position = UDim2.new(1,-110,1,-44)
    getKeyBtn.Text = "Get Key"
    getKeyBtn.Font = Enum.Font.SourceSansBold
    getKeyBtn.TextSize = 16
    getKeyBtn.BackgroundColor3 = Color3.fromRGB(80,200,160)
    getKeyBtn.TextColor3 = Color3.fromRGB(0,0,0)

    local status = Instance.new("TextLabel", frame)
    status.Size = UDim2.new(1,-20,0,20)
    status.Position = UDim2.new(0,10,1,-20)
    status.BackgroundTransparency = 1
    status.Text = "Status: waiting for key"
    status.TextColor3 = Color3.fromRGB(170,190,210)
    status.Font = Enum.Font.SourceSans
    status.TextSize = 14
    status.TextXAlignment = Enum.TextXAlignment.Left

    return {screenGui=screenGui, frame=frame, textBox=textBox, joinBtn=joinBtn, getKeyBtn=getKeyBtn, status=status}
end

-- Main cheat UI (shown after validation)
local function createMainUI()
    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = "FrogMainGui"
    screenGui.ResetOnSpawn = false
    screenGui.Parent = LocalPlayer:WaitForChild("PlayerGui")

    local frame = Instance.new("Frame", screenGui)
    frame.Size = UDim2.new(0,420,0,260)
    frame.Position = UDim2.new(0.5,-210,0.3,-130)
    frame.BackgroundColor3 = Color3.fromRGB(12,18,24)
    frame.BorderSizePixel = 0
    frame.Active = true
    frame.Draggable = true

    local title = Instance.new("TextLabel", frame)
    title.Size = UDim2.new(1,-20,0,28)
    title.Position = UDim2.new(0,10,0,8)
    title.BackgroundTransparency = 1
    title.Text = "Frog Suite"
    title.TextColor3 = Color3.new(0.9,0.95,1)
    title.Font = Enum.Font.SourceSansBold
    title.TextSize = 20
    title.TextXAlignment = Enum.TextXAlignment.Left

    -- ESP Toggle
    local espToggle = Instance.new("TextButton", frame)
    espToggle.Size = UDim2.new(0,120,0,30)
    espToggle.Position = UDim2.new(0,10,0,48)
    espToggle.Text = "ESP: OFF"
    espToggle.TextSize = 14
    espToggle.Font = Enum.Font.SourceSansBold
    espToggle.BackgroundColor3 = Color3.fromRGB(80,80,80)
    espToggle.TextColor3 = Color3.new(1,1,1)

    -- Speed control
    local speedLabel = Instance.new("TextLabel", frame)
    speedLabel.Size = UDim2.new(0,120,0,20)
    speedLabel.Position = UDim2.new(0,10,0,90)
    speedLabel.BackgroundTransparency = 1
    speedLabel.Text = "Speed: 16"
    speedLabel.TextSize = 14
    speedLabel.TextColor3 = Color3.new(0.9,0.9,0.9)
    speedLabel.Font = Enum.Font.SourceSans

    local speedSlider = Instance.new("TextButton", frame)
    speedSlider.Size = UDim2.new(0,200,0,20)
    speedSlider.Position = UDim2.new(0,140,0,90)
    speedSlider.Text = "Adjust Speed"
    speedSlider.Font = Enum.Font.SourceSans
    speedSlider.TextSize = 14
    speedSlider.BackgroundColor3 = Color3.fromRGB(70,70,70)
    speedSlider.TextColor3 = Color3.new(1,1,1)

    local flyToggle = Instance.new("TextButton", frame)
    flyToggle.Size = UDim2.new(0,120,0,30)
    flyToggle.Position = UDim2.new(0,10,0,124)
    flyToggle.Text = "Fly: OFF"
    flyToggle.TextSize = 14
    flyToggle.Font = Enum.Font.SourceSansBold
    flyToggle.BackgroundColor3 = Color3.fromRGB(80,80,80)
    flyToggle.TextColor3 = Color3.new(1,1,1)

    local closeBtn = Instance.new("TextButton", frame)
    closeBtn.Size = UDim2.new(0,60,0,28)
    closeBtn.Position = UDim2.new(1,-70,0,8)
    closeBtn.Text = "Close"
    closeBtn.Font = Enum.Font.SourceSansBold
    closeBtn.TextSize = 14
    closeBtn.BackgroundColor3 = Color3.fromRGB(180,60,60)
    closeBtn.TextColor3 = Color3.new(1,1,1)

    return {screenGui=screenGui, espToggle=espToggle, speedLabel=speedLabel, speedSlider=speedSlider, flyToggle=flyToggle, closeBtn=closeBtn, frame=frame}
end

-- ESP implementation using BillboardGui (no external Drawing required)
local ESP = {}
ESP.enabled = false
ESP.guis = {}

function ESP.toggle(state)
    ESP.enabled = state
    if not state then
        for _,g in pairs(ESP.guis) do
            if g and g:FindFirstAncestor(game) then g:Destroy() end
        end
        ESP.guis = {}
    else
        -- create guis for players
        for _,p in pairs(Players:GetPlayers()) do
            if p ~= LocalPlayer then
                local root = p.Character and (p.Character:FindFirstChild("Head") or p.Character:FindFirstChildWhichIsA("BasePart"))
                if root then
                    local bg = Instance.new("BillboardGui")
                    bg.Name = "FrogESP"
                    bg.AlwaysOnTop = true
                    bg.Size = UDim2.new(0,120,0,40)
                    bg.Adornee = root
                    bg.Parent = LocalPlayer:WaitForChild("PlayerGui")
                    local lbl = Instance.new("TextLabel", bg)
                    lbl.Size = UDim2.new(1,0,1,0)
                    lbl.BackgroundTransparency = 1
                    lbl.Text = p.Name .. \"\\n\" .. math.floor((LocalPlayer.Character and LocalPlayer.Character:FindFirstChild('HumanoidRootPart') and (LocalPlayer.Character.HumanoidRootPart.Position - root.Position).Magnitude) or 0) .. \" studs\"
                    lbl.TextColor3 = Color3.new(1,0.7,0.2)
                    lbl.Font = Enum.Font.SourceSansBold
                    lbl.TextScaled = true
                    ESP.guis[p] = bg
                end
            end
        end
    end
end

-- cleanup when players join/leave
Players.PlayerRemoving:Connect(function(pl) if ESP.guis[pl] then ESP.guis[pl]:Destroy(); ESP.guis[pl]=nil end end)
Players.PlayerAdded:Connect(function(pl) if ESP.enabled then wait(0.5); ESP.toggle(true) end end)

-- Speed controller
local speed = {value = 16, conn = nil}
function speed.set(v)
    speed.value = v
    local char = LocalPlayer.Character
    if char and char:FindFirstChild('Humanoid') then
        char.Humanoid.WalkSpeed = v
    end
end

-- Fly simple implementation
local flyState = {enabled=false, bv=nil, bg=nil, conn=nil}
function flyState.toggle(state)
    local char = LocalPlayer.Character
    if not char or not char:FindFirstChild('HumanoidRootPart') then return end
    if state == flyState.enabled then return end
    flyState.enabled = state
    if state then
        local hrp = char.HumanoidRootPart
        local bv = Instance.new("BodyVelocity", hrp)
        bv.MaxForce = Vector3.new(9e9,9e9,9e9)
        bv.Velocity = Vector3.new(0,0,0)
        local bg = Instance.new("BodyGyro", hrp)
        bg.MaxTorque = Vector3.new(9e9,9e9,9e9)
        flyState.bv = bv; flyState.bg = bg
        flyState.conn = game:GetService("RunService").RenderStepped:Connect(function()
            local cam = workspace.CurrentCamera
            if not cam then return end
            local dir = Vector3.new()
            if UserInputService:IsKeyDown(Enum.KeyCode.W) then dir = dir + cam.CFrame.LookVector end
            if UserInputService:IsKeyDown(Enum.KeyCode.S) then dir = dir - cam.CFrame.LookVector end
            if UserInputService:IsKeyDown(Enum.KeyCode.A) then dir = dir - cam.CFrame.RightVector end
            if UserInputService:IsKeyDown(Enum.KeyCode.D) then dir = dir + cam.CFrame.RightVector end
            bv.Velocity = dir.Unit * (speed.value or 50) + Vector3.new(0,0,0)
        end)
    else
        if flyState.conn then flyState.conn:Disconnect(); flyState.conn = nil end
        if flyState.bv then flyState.bv:Destroy(); flyState.bv = nil end
        if flyState.bg then flyState.bg:Destroy(); flyState.bg = nil end
    end
end

-- high-level flow
local ui = createGui()
local main = nil

-- button behaviors
ui.getKeyBtn.MouseButton1Click:Connect(function()
    -- attempt to open website in browser or copy URL to clipboard
    pcall(function()
        if syn and syn.request then
            -- copy to clipboard as many executors allow it
            if setclipboard then setclipboard(SITE_URL) end
        end
        pcall(function() game:GetService('GuiService'):OpenBrowserWindow(SITE_URL) end)
    end)
end)

ui.joinBtn.MouseButton1Click:Connect(function()
    pcall(function() game:GetService('GuiService'):OpenBrowserWindow(DISCORD_INVITE) end)
end)

local function validateKey(k)
    if type(k) ~= 'string' then return false, 'not_string' end
    if not k:match('^frog%-') then return false, 'format' end
    local url = SITE_URL .. '/api/validate?key=' .. HttpService:UrlEncode(k)
    local res, err = httpRequest(url)
    if not res then return false, ('http_err:' .. (err or 'unknown')) end
    -- Response shapes differ depending on http lib. Try to parse body.
    local body = res.Body or res.body or res[1] or res
    if type(body) == 'table' then
        -- syn.request-like returns table
        if body.StatusCode and body.StatusCode ~= 200 then return false, 'status_'..tostring(body.StatusCode) end
        local parsed = body.Body and HttpService:JSONDecode(body.Body) or body
        return parsed.valid, parsed.reason or parsed.error or parsed.valid
    else
        -- body likely a JSON string
        local ok, parsed = pcall(function() return HttpService:JSONDecode(tostring(body)) end)
        if not ok then return false, 'bad_json' end
        return parsed.valid, parsed.reason or parsed.error or parsed.valid
    end
end

ui.textBox.FocusLost:Connect(function(enter)
    local k = ui.textBox.Text or ''
    ui.status.Text = 'Validating...'
    spawn(function()
        local ok, msg = validateKey(k)
        if ok then
            ui.status.Text = 'Key valid — unlocking UI'
            wait(0.3)
            -- destroy key UI and create main UI
            pcall(function() ui.screenGui:Destroy() end)
            main = createMainUI()
            -- wire main UI controls
            main.espToggle.MouseButton1Click:Connect(function()
                local newState = not ESP.enabled
                ESP.toggle(newState)
                main.espToggle.Text = 'ESP: ' .. (newState and 'ON' or 'OFF')
                main.espToggle.BackgroundColor3 = newState and Color3.fromRGB(50,120,50) or Color3.fromRGB(80,80,80)
            end)
            -- speed slider: simplified — cycles speeds on click
            local speeds = {16,24,36,50,80}
            local idx = 1
            main.speedSlider.MouseButton1Click:Connect(function()
                idx = idx + 1
                if idx > #speeds then idx = 1 end
                speed.set(speeds[idx])
                main.speedLabel.Text = 'Speed: ' .. tostring(speeds[idx])
            end)
            -- fly toggle
            main.flyToggle.MouseButton1Click:Connect(function()
                flyState.toggle(not flyState.enabled)
                main.flyToggle.Text = 'Fly: ' .. (flyState.enabled and 'ON' or 'OFF')
                main.flyToggle.BackgroundColor3 = flyState.enabled and Color3.fromRGB(50,120,50) or Color3.fromRGB(80,80,80)
            end)
            main.closeBtn.MouseButton1Click:Connect(function() pcall(function() main.screenGui:Destroy() end) end)
        else
            ui.status.Text = 'Invalid key: ' .. tostring(msg or 'unknown')
        end
    end)
end)

-- Ensure speed applied when character respawns
Players.PlayerAdded:Connect(function(pl)
    if pl == LocalPlayer then
        pl.CharacterAdded:Connect(function(char)
            wait(1)
            speed.set(speed.value or 16)
        end)
    end
end)
if LocalPlayer.Character then speed.set(16) end

-- End of script
